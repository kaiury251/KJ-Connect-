package com.example.darkconnect.network.connection

import com.example.darkconnect.network.diagnostics.Endpoint

enum class ConnectionState { DISCONNECTED, CONNECTING, CONNECTED, ERROR }

data class ConnectionStatus(
    val state: ConnectionState = ConnectionState.DISCONNECTED,
    val errorMessage: String? = null,
    /** Início da sessão (para tempo DECORRIDO). Não existe prazo de expiração. */
    val connectedAtMillis: Long? = null,
)

data class ConnectionConfig(
    val serverName: String,
    val endpoint: Endpoint,
    val profileId: Int,
    val profileName: String,
)
