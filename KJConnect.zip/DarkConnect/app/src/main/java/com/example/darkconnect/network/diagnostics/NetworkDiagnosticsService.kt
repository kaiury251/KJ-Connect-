package com.example.darkconnect.network.diagnostics

import kotlinx.coroutines.flow.Flow

data class Endpoint(val host: String, val port: Int)

sealed interface LatencyResult {
    data class Success(val ms: Long) : LatencyResult
    object Timeout : LatencyResult
    data class Unreachable(val reason: String) : LatencyResult
}

/** Contrato da camada de diagnóstico. A UI/ViewModel dependem só desta interface. */
interface NetworkDiagnosticsService {
    /** IPv4 local da rede ativa, ou null se não houver rede utilizável. */
    fun currentLocalIpv4(): String?

    /** Emite novamente sempre que a rede ativa mudar (Wi-Fi <-> dados, queda, etc.). */
    fun observeLocalIpv4(): Flow<String?>

    /** Tempo de conexão TCP (sem DNS) até o endpoint. Nunca lança exceção. */
    suspend fun measureLatency(endpoint: Endpoint, timeoutMs: Int = 3000): LatencyResult

    /** Mede vários endpoints com concorrência limitada, emitindo cada resultado assim que chega. */
    fun measureAll(endpoints: List<Endpoint>, timeoutMs: Int = 3000, concurrency: Int = 8): Flow<Pair<Endpoint, LatencyResult>>
}
