package com.example.darkconnect.ui.servers

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.darkconnect.data.MockData
import com.example.darkconnect.data.Server
import com.example.darkconnect.data.toSignal
import com.example.darkconnect.network.diagnostics.Endpoint
import com.example.darkconnect.network.diagnostics.LatencyResult
import com.example.darkconnect.ui.components.*
import com.example.darkconnect.ui.theme.AppColors

@Composable
fun ServersScreen(
    selected: Server, randomActive: Boolean,
    latencies: Map<Endpoint, LatencyResult>, measuring: Boolean,
    onRefresh: () -> Unit,
    onSelect: (Server) -> Unit, onRandom: () -> Unit, onBack: () -> Unit,
) {
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { onRefresh() }          // mede ao abrir a tela

    val list = MockData.servers.filter {
        query.isBlank() || it.code.contains(query, true) || it.country.contains(query, true)
    }

    Column(Modifier.fillMaxSize().background(AppColors.Black)) {
        ScreenHeader("SERVIDORES", onBack, onSearch = { searching = !searching; if (!searching) query = "" })
        if (searching) SearchField(query) { query = it }
        Text(
            if (measuring) "MEDINDO LATÊNCIA…" else "TOQUE AQUI PARA MEDIR NOVAMENTE",
            Modifier.fillMaxWidth().clickable(enabled = !measuring, onClick = onRefresh).padding(horizontal = 16.dp, vertical = 6.dp),
            style = MaterialTheme.typography.labelSmall, color = AppColors.TextSecondary
        )

        LazyColumn(
            contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 32.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                AppCard(selected = randomActive, onClick = onRandom) {
                    Icon(Icons.Filled.Shuffle, null, tint = AppColors.Cyan, modifier = Modifier.size(40.dp))
                    TitleSubtitle("SERVIDOR ALEATÓRIO", "ESCOLHA AUTOMÁTICA", Modifier.weight(1f).padding(start = 12.dp))
                    Text(
                        "AUTO",
                        Modifier.clip(RoundedCornerShape(6.dp)).background(AppColors.Cyan).padding(horizontal = 8.dp, vertical = 3.dp),
                        style = MaterialTheme.typography.labelSmall, color = Color.Black
                    )
                }
            }
            items(list, key = { it.code }) { s ->
                val r = latencies[s.endpoint]
                AppCard(selected = !randomActive && s.code == selected.code, onClick = { onSelect(s) }) {
                    EmojiBadge(s.flag)
                    TitleSubtitle(s.code, s.country, Modifier.weight(1f).padding(start = 12.dp))
                    Text(
                        when (r) {
                            is LatencyResult.Success -> "${r.ms} ms"
                            LatencyResult.Timeout -> "TIMEOUT"
                            is LatencyResult.Unreachable -> "OFF"
                            null -> if (measuring) "…" else "—"
                        },
                        Modifier.padding(end = 10.dp),
                        style = MaterialTheme.typography.labelSmall, color = AppColors.TextSecondary
                    )
                    SignalBars(r.toSignal())
                }
            }
        }
    }
}
