package com.example.darkconnect

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.darkconnect.ui.connections.ConnectionsScreen
import com.example.darkconnect.ui.home.HomeScreen
import com.example.darkconnect.ui.logs.LogsScreen
import com.example.darkconnect.ui.servers.ServersScreen
import com.example.darkconnect.ui.theme.AppTheme

enum class Route { HOME, CONNECTIONS, SERVERS, LOGS }

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels {
        AppViewModel.factory((application as DarkConnectApp).container)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AppTheme {
                val state by vm.state.collectAsStateWithLifecycle()
                val logs by vm.logs.collectAsStateWithLifecycle()
                var route by rememberSaveable { mutableStateOf(Route.HOME) }
                BackHandler(route != Route.HOME) { route = Route.HOME }

                when (route) {
                    Route.HOME -> HomeScreen(
                        state, onToggle = vm::toggleConnection,
                        onOpenServers = { route = Route.SERVERS },
                        onOpenConnections = { route = Route.CONNECTIONS },
                        onOpenLogs = { route = Route.LOGS },
                        onAdd = { route = Route.CONNECTIONS },
                    )
                    Route.CONNECTIONS -> ConnectionsScreen(
                        selected = state.profile,
                        onSelect = { vm.selectProfile(it); route = Route.HOME },
                        onBack = { route = Route.HOME },
                    )
                    Route.SERVERS -> ServersScreen(
                        selected = state.server, randomActive = state.randomServer,
                        latencies = state.latencies, measuring = state.measuring,
                        onRefresh = vm::refreshLatencies,
                        onSelect = { vm.selectServer(it); route = Route.HOME },
                        onRandom = { vm.selectRandomServer(); route = Route.HOME },
                        onBack = { route = Route.HOME },
                    )
                    Route.LOGS -> LogsScreen(logs, onClear = vm::clearLogs, onBack = { route = Route.HOME })
                }
            }
        }
    }
}
