package com.example.darkconnect.network.diagnostics

import android.content.Context
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.Network
import android.net.NetworkCapabilities
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.SocketTimeoutException
import java.net.UnknownHostException

class AndroidNetworkDiagnostics(context: Context) : NetworkDiagnosticsService {

    private val cm = context.applicationContext.getSystemService(ConnectivityManager::class.java)

    override fun currentLocalIpv4(): String? {
        val network = cm.activeNetwork ?: return null
        val caps = cm.getNetworkCapabilities(network) ?: return null
        if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) return null
        val props = cm.getLinkProperties(network) ?: return null
        return props.linkAddresses
            .map { it.address }
            .filterIsInstance<Inet4Address>()
            .firstOrNull { !it.isLoopbackAddress && !it.isLinkLocalAddress && !it.isAnyLocalAddress }
            ?.hostAddress
    }

    override fun observeLocalIpv4(): Flow<String?> = callbackFlow<String?> {
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { trySend(currentLocalIpv4()) }
            override fun onLinkPropertiesChanged(network: Network, lp: LinkProperties) { trySend(currentLocalIpv4()) }
            override fun onLost(network: Network) { trySend(currentLocalIpv4()) }
        }
        trySend(currentLocalIpv4())
        cm.registerDefaultNetworkCallback(callback)
        awaitClose { cm.unregisterNetworkCallback(callback) }
    }.distinctUntilChanged()

    override suspend fun measureLatency(endpoint: Endpoint, timeoutMs: Int): LatencyResult =
        withContext(Dispatchers.IO) {
            val network = cm.activeNetwork
                ?: return@withContext LatencyResult.Unreachable("sem rede ativa")
            // DNS fora da medição: o ping reflete só o tempo de handshake TCP.
            val address = try {
                network.getAllByName(endpoint.host).first()
            } catch (e: UnknownHostException) {
                return@withContext LatencyResult.Unreachable("DNS não resolveu ${endpoint.host}")
            } catch (e: Exception) {
                return@withContext LatencyResult.Unreachable(e.message ?: "falha de DNS")
            }
            val socket = network.socketFactory.createSocket()
            try {
                val start = System.nanoTime()
                socket.connect(InetSocketAddress(address, endpoint.port), timeoutMs)
                LatencyResult.Success((System.nanoTime() - start) / 1_000_000)
            } catch (e: SocketTimeoutException) {
                LatencyResult.Timeout
            } catch (e: Exception) {
                LatencyResult.Unreachable(e.message ?: e.javaClass.simpleName)
            } finally {
                runCatching { socket.close() }
            }
        }

    override fun measureAll(
        endpoints: List<Endpoint>, timeoutMs: Int, concurrency: Int
    ): Flow<Pair<Endpoint, LatencyResult>> = channelFlow<Pair<Endpoint, LatencyResult>> {
        val gate = Semaphore(concurrency)
        endpoints.forEach { ep ->
            launch { gate.withPermit { send(ep to measureLatency(ep, timeoutMs)) } }
        }
    }
}
