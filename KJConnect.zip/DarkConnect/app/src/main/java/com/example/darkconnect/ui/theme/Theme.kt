package com.example.darkconnect.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object AppColors {
    val Black = Color(0xFF000000)
    val Bg = Color(0xFF0A0B0E)
    val Card = Color(0xFF1E2026)
    val CardAlt = Color(0xFF2A2D36)
    val Border = Color(0xFF353945)
    val Cyan = Color(0xFF00E5FF)
    val Blue = Color(0xFF2979FF)
    val Green = Color(0xFF00E676)
    val Yellow = Color(0xFFFFC400)
    val Red = Color(0xFFFF5252)
    val TextPrimary = Color(0xFFFFFFFF)
    val TextSecondary = Color(0xFF8A8F9C)
}

private val Font = FontFamily.SansSerif
val AppTypography = Typography(
    titleLarge = TextStyle(fontFamily = Font, fontWeight = FontWeight.Black, fontSize = 20.sp, letterSpacing = 1.5.sp),
    titleMedium = TextStyle(fontFamily = Font, fontWeight = FontWeight.Bold, fontSize = 16.sp, letterSpacing = 1.sp),
    bodyMedium = TextStyle(fontFamily = Font, fontWeight = FontWeight.Medium, fontSize = 12.sp, letterSpacing = 1.sp),
    labelSmall = TextStyle(fontFamily = Font, fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 1.2.sp),
)

@Composable
fun AppTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(
        background = AppColors.Bg, surface = AppColors.Card,
        primary = AppColors.Cyan, onBackground = AppColors.TextPrimary, onSurface = AppColors.TextPrimary
    ),
    typography = AppTypography,
    content = content
)
