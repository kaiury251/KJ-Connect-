package com.example.darkconnect.data

object MockData {
    const val APP_NAME = "SOCKSLITE PRO"   // nome customizável do banner
    const val VERSION = "5.2.1"

    // CATÁLOGO DE ENDPOINTS: substitua pelos seus hosts/portas reais (ou carregue de config/API).
    val servers: List<Server> =
        (1..51).map { Server("BR %02d".format(it), "🇧🇷", "BRASIL", "br%02d.example.com".format(it), 443) } +
        (11..20).map { Server("USA $it", "🇺🇸", "ESTADOS UNIDOS", "us$it.example.com", 443) }

    val profiles: List<Profile> = listOf(
        Profile(1, "🛰️", "VIVO FLARE 13", "PLANO CONTROLE", ConnStatus.VERIFIED),
        Profile(2, "⚡", "VIVO FLARE 14", "PLANO PRÉ-PAGO", ConnStatus.ALERT),
        Profile(3, "🔥", "CLARO NEO 02", "PLANO CONTROLE", ConnStatus.VERIFIED),
        Profile(4, "🌐", "OI WAVE 07", "PLANO PÓS-PAGO", ConnStatus.ALERT),
        Profile(5, "🚀", "TIM SPARK 21", "PLANO PRÉ-PAGO", ConnStatus.VERIFIED),
        Profile(6, "💎", "WIFI HOME 01", "REDE RESIDENCIAL", ConnStatus.VERIFIED),
    )

    private fun group(name: String, n: Int, base: Int) = ProfileGroup(
        name, (1..n).map {
            Profile(base + it, "📡", "$name $it", "PERFIL AUTOMÁTICO",
                if (it % 2 == 0) ConnStatus.ALERT else ConnStatus.VERIFIED)
        }
    )

    val groups = listOf(
        group("VIVO FRONT", 4, 100), group("VIVO DIRECT", 6, 200), group("VIVO DNSTT", 3, 300),
        group("TIM AZION", 5, 400), group("TIM FRONT", 4, 500),
    )
}
