package com.example.darkconnect

import android.app.Application
import com.example.darkconnect.network.connection.ConnectionController
import com.example.darkconnect.network.connection.TunnelEngine
import com.example.darkconnect.network.connection.UnimplementedTunnelEngine
import com.example.darkconnect.network.diagnostics.AndroidNetworkDiagnostics
import com.example.darkconnect.network.diagnostics.NetworkDiagnosticsService
import com.example.darkconnect.network.log.LogRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/** Injeção manual de dependências (troque por Hilt/Koin se preferir). */
class AppContainer(app: Application) {
    val logs = LogRepository()
    val diagnostics: NetworkDiagnosticsService = AndroidNetworkDiagnostics(app)

    // >>> PONTO DE INTEGRAÇÃO: troque pelo seu motor real (ex.: VpnTunnelEngine(app)) <<<
    val engine: TunnelEngine = UnimplementedTunnelEngine()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    val controller = ConnectionController(diagnostics, engine, logs, scope)
}

class DarkConnectApp : Application() {
    lateinit var container: AppContainer
    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
