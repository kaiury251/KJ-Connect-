package com.example.darkconnect.ui.logs

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.darkconnect.network.log.LogEntry
import com.example.darkconnect.network.log.LogLevel
import com.example.darkconnect.ui.components.ScreenHeader
import com.example.darkconnect.ui.theme.AppColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun LogsScreen(entries: List<LogEntry>, onClear: () -> Unit, onBack: () -> Unit) {
    val listState = rememberLazyListState()
    val fmt = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }
    LaunchedEffect(entries.size) { if (entries.isNotEmpty()) listState.animateScrollToItem(entries.lastIndex) }

    Column(Modifier.fillMaxSize().background(AppColors.Black)) {
        ScreenHeader("REGISTRO", onBack, onSearch = null)
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)) {
            Text("${entries.size} EVENTOS", Modifier.weight(1f), style = MaterialTheme.typography.labelSmall, color = AppColors.TextSecondary)
            Text("LIMPAR", Modifier.clickable(onClick = onClear), style = MaterialTheme.typography.labelSmall, color = AppColors.Cyan)
        }
        if (entries.isEmpty()) {
            Text("Nenhum evento ainda. Toque no botão power para ver o registro.",
                Modifier.padding(16.dp), style = MaterialTheme.typography.bodyMedium, color = AppColors.TextSecondary)
        }
        LazyColumn(
            state = listState,
            contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 24.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(entries) { e ->
                val color = when (e.level) {
                    LogLevel.INFO -> AppColors.TextSecondary
                    LogLevel.SUCCESS -> AppColors.Green
                    LogLevel.WARN -> AppColors.Yellow
                    LogLevel.ERROR -> AppColors.Red
                }
                Row {
                    Text(fmt.format(Date(e.timestamp)), Modifier.width(64.dp), style = MaterialTheme.typography.labelSmall, color = AppColors.TextSecondary)
                    Text(e.message, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, color = color)
                }
            }
        }
    }
}
