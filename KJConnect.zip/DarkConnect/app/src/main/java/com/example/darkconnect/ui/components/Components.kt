package com.example.darkconnect.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.darkconnect.data.ConnStatus
import com.example.darkconnect.data.Signal
import com.example.darkconnect.network.connection.ConnectionState
import com.example.darkconnect.ui.theme.AppColors

@Composable
fun SignalBars(signal: Signal, modifier: Modifier = Modifier) {
    val (active, color) = when (signal) {
        Signal.HIGH -> 4 to AppColors.Green
        Signal.MEDIUM -> 3 to AppColors.Yellow
        Signal.LOW -> 1 to AppColors.Red
        Signal.UNAVAILABLE -> 0 to AppColors.TextSecondary
    }
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.Bottom) {
        (1..4).forEach { i ->
            Box(
                Modifier.width(5.dp).height((6 + i * 4).dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(if (i <= active) color else AppColors.CardAlt)
            )
        }
    }
}

@Composable
fun StatusIcon(status: ConnStatus) = when (status) {
    ConnStatus.VERIFIED -> Icon(Icons.Filled.VerifiedUser, null, tint = AppColors.Green)
    ConnStatus.ALERT -> Icon(Icons.Filled.Message, null, tint = AppColors.Yellow)
}

/** Card padrão clicável; selected => borda ciano com realce. */
@Composable
fun AppCard(
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    onClick: () -> Unit = {},
    content: @Composable RowScope.() -> Unit,
) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(if (selected) AppColors.CardAlt else AppColors.Card)
            .border(BorderStroke(if (selected) 1.5.dp else 1.dp, if (selected) AppColors.Cyan else AppColors.Border), shape)
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        content = content
    )
}

@Composable
fun EmojiBadge(emoji: String, size: Int = 44) {
    Box(
        Modifier.size(size.dp).clip(RoundedCornerShape(12.dp)).background(AppColors.Bg)
            .border(1.dp, AppColors.Border, RoundedCornerShape(12.dp)),
        contentAlignment = Alignment.Center
    ) { Text(emoji, fontSize = (size * 0.5f).sp) }
}

@Composable
fun TitleSubtitle(title: String, subtitle: String, modifier: Modifier = Modifier) {
    Column(modifier) {
        Text(title, style = MaterialTheme.typography.titleMedium, color = AppColors.TextPrimary)
        Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = AppColors.TextSecondary)
    }
}

@Composable
fun ScreenHeader(
    title: String,
    onBack: () -> Unit,
    onSearch: (() -> Unit)?,
    onAdd: (() -> Unit)? = null,
) {
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onBack) { Icon(Icons.Filled.ArrowBack, null, tint = AppColors.TextPrimary) }
        Text(title, Modifier.weight(1f), style = MaterialTheme.typography.titleLarge, color = AppColors.TextPrimary)
        if (onSearch != null) IconButton(onSearch) { Icon(Icons.Filled.Search, null, tint = AppColors.Cyan) }
        if (onAdd != null) IconButton(onAdd) { Icon(Icons.Filled.Add, null, tint = AppColors.Cyan) }
    }
}

@Composable
fun SearchField(value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value, onChange,
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
        placeholder = { Text("BUSCAR…", color = AppColors.TextSecondary) },
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = AppColors.Cyan, unfocusedBorderColor = AppColors.Border,
            focusedContainerColor = AppColors.Card, unfocusedContainerColor = AppColors.Card,
            cursorColor = AppColors.Cyan
        )
    )
}

@Composable
fun PowerButton(state: ConnectionState, onClick: () -> Unit) {
    val ring = when (state) {
        ConnectionState.CONNECTED -> listOf(AppColors.Cyan, AppColors.Blue, AppColors.Cyan)
        ConnectionState.CONNECTING -> listOf(AppColors.Yellow, AppColors.CardAlt, AppColors.Yellow)
        ConnectionState.ERROR -> listOf(AppColors.Red, AppColors.CardAlt, AppColors.Red)
        ConnectionState.DISCONNECTED -> listOf(AppColors.Border, AppColors.CardAlt, AppColors.Border)
    }
    val tint = when (state) {
        ConnectionState.CONNECTED -> AppColors.Cyan
        ConnectionState.CONNECTING -> AppColors.Yellow
        ConnectionState.ERROR -> AppColors.Red
        ConnectionState.DISCONNECTED -> AppColors.TextSecondary
    }
    Box(
        Modifier.size(170.dp)
            .shadow(if (state == ConnectionState.CONNECTED) 28.dp else 0.dp, CircleShape, ambientColor = AppColors.Cyan, spotColor = AppColors.Cyan)
            .clip(CircleShape)
            .background(AppColors.Bg)
            .border(4.dp, Brush.sweepGradient(ring), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (state == ConnectionState.CONNECTING)
            CircularProgressIndicator(Modifier.size(150.dp), color = AppColors.Yellow, strokeWidth = 3.dp)
        Icon(Icons.Filled.PowerSettingsNew, "Conectar", Modifier.size(72.dp), tint = tint)
    }
}

@Composable
fun GradientPill(text: String) {
    Box(
        Modifier.clip(RoundedCornerShape(50))
            .background(Brush.horizontalGradient(listOf(AppColors.Blue, AppColors.Cyan)))
            .padding(horizontal = 28.dp, vertical = 8.dp)
    ) { Text(text, style = MaterialTheme.typography.titleMedium, color = Color.Black) }
}

@Composable
fun AppBottomBar(onSettings: () -> Unit, onLogs: () -> Unit, onRocket: () -> Unit, onUpdate: () -> Unit, onTools: () -> Unit) {
    Box(Modifier.fillMaxWidth().navigationBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().background(AppColors.Black).border(1.dp, AppColors.Border)
                .padding(vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically
        ) {
            BarItem(Icons.Filled.Settings, "AJUSTES", onClick = onSettings)
            BarItem(Icons.Filled.Description, "REGISTRO", badge = "LOGS", onClick = onLogs)
            Spacer(Modifier.width(64.dp))
            BarItem(Icons.Filled.Refresh, "ATUALIZAR", onClick = onUpdate)
            BarItem(Icons.Filled.Build, "FERRAMENTAS", onClick = onTools)
        }
        Box(
            Modifier.align(Alignment.TopCenter).offset(y = (-22).dp).size(64.dp)
                .shadow(14.dp, CircleShape, ambientColor = AppColors.Cyan, spotColor = AppColors.Cyan)
                .clip(CircleShape)
                .background(Brush.verticalGradient(listOf(AppColors.Cyan, AppColors.Blue)))
                .border(3.dp, AppColors.Black, CircleShape)
                .clickable(onClick = onRocket),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Filled.RocketLaunch, null, tint = Color.Black, modifier = Modifier.size(30.dp)) }
    }
}

@Composable
private fun BarItem(icon: ImageVector, label: String, badge: String? = null, onClick: () -> Unit) {
    Column(Modifier.clickable(onClick = onClick).padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box {
            Icon(icon, label, tint = AppColors.TextSecondary)
            if (badge != null) Text(
                badge, Modifier.align(Alignment.TopEnd).offset(x = 14.dp, y = (-6).dp)
                    .background(AppColors.Cyan, RoundedCornerShape(4.dp)).padding(horizontal = 3.dp),
                fontSize = 7.sp, color = Color.Black, textAlign = TextAlign.Center
            )
        }
        Text(label, style = MaterialTheme.typography.labelSmall, color = AppColors.TextSecondary)
    }
}
