package com.example.darkconnect.ui.connections

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.darkconnect.data.MockData
import com.example.darkconnect.data.Profile
import com.example.darkconnect.ui.components.*
import com.example.darkconnect.ui.theme.AppColors

@Composable
fun ConnectionsScreen(selected: Profile, onSelect: (Profile) -> Unit, onBack: () -> Unit) {
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(setOf<String>()) }
    fun match(p: Profile) = query.isBlank() || p.title.contains(query, true) || p.subtitle.contains(query, true)

    Column(Modifier.fillMaxSize().background(AppColors.Black)) {
        ScreenHeader("CONEXÕES", onBack, onSearch = { searching = !searching; if (!searching) query = "" }, onAdd = {})
        if (searching) SearchField(query) { query = it }

        LazyColumn(
            contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 32.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(MockData.profiles.filter(::match), key = { it.id }) { p ->
                ProfileRow(p, number = p.id, selected = p.id == selected.id) { onSelect(p) }
            }
            item { Spacer(Modifier.height(6.dp)) }
            MockData.groups.forEach { g ->
                item(key = g.name) {
                    val open = g.name in expanded
                    AppCard(onClick = { expanded = if (open) expanded - g.name else expanded + g.name }) {
                        Text(g.name, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium, color = AppColors.TextPrimary)
                        Text("${g.count}", style = MaterialTheme.typography.titleMedium, color = AppColors.Cyan)
                        Icon(if (open) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore, null, tint = AppColors.TextSecondary)
                    }
                }
                if (g.name in expanded) {
                    items(g.items.filter(::match), key = { it.id }) { p ->
                        ProfileRow(p, number = p.id % 100, selected = p.id == selected.id, Modifier.padding(start = 16.dp)) { onSelect(p) }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProfileRow(p: Profile, number: Int, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    AppCard(modifier, selected, onClick) {
        Text("$number", Modifier.width(28.dp), style = MaterialTheme.typography.titleMedium, color = AppColors.TextSecondary)
        EmojiBadge(p.emoji)
        TitleSubtitle(p.title, p.subtitle, Modifier.weight(1f).padding(horizontal = 12.dp))
        StatusIcon(p.status)
    }
}
