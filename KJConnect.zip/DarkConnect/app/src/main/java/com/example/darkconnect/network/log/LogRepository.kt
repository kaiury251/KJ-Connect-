package com.example.darkconnect.network.log

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

enum class LogLevel { INFO, SUCCESS, WARN, ERROR }

data class LogEntry(val timestamp: Long, val level: LogLevel, val message: String)

/** Fonte única de logs. A tela REGISTRO só observa [entries]. */
class LogRepository(private val maxEntries: Int = 500) {
    private val _entries = MutableStateFlow<List<LogEntry>>(emptyList())
    val entries: StateFlow<List<LogEntry>> = _entries.asStateFlow()

    fun log(level: LogLevel, message: String) =
        _entries.update { (it + LogEntry(System.currentTimeMillis(), level, message)).takeLast(maxEntries) }

    fun info(m: String) = log(LogLevel.INFO, m)
    fun success(m: String) = log(LogLevel.SUCCESS, m)
    fun warn(m: String) = log(LogLevel.WARN, m)
    fun error(m: String) = log(LogLevel.ERROR, m)
    fun clear() { _entries.value = emptyList() }
}
