package com.example.darkconnect

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.darkconnect.data.MockData
import com.example.darkconnect.data.Profile
import com.example.darkconnect.data.Server
import com.example.darkconnect.network.connection.ConnectionConfig
import com.example.darkconnect.network.connection.ConnectionState
import com.example.darkconnect.network.connection.ConnectionStatus
import com.example.darkconnect.network.diagnostics.Endpoint
import com.example.darkconnect.network.diagnostics.LatencyResult
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class AppState(
    val connection: ConnectionStatus = ConnectionStatus(),
    val elapsedSeconds: Long = 0,                       // tempo decorrido (count-up)
    val server: Server = MockData.servers.first { it.code == "BR 30" },
    val profile: Profile = MockData.profiles.first(),
    val randomServer: Boolean = false,
    val localIp: String? = null,                        // null => "SEM REDE"
    val latencies: Map<Endpoint, LatencyResult> = emptyMap(),
    val measuring: Boolean = false,
)

class AppViewModel(private val c: AppContainer) : ViewModel() {
    private val _state = MutableStateFlow(AppState())
    val state: StateFlow<AppState> = _state
    val logs = c.logs.entries

    private var measureJob: Job? = null

    init {
        viewModelScope.launch {
            c.controller.status.collect { s ->
                _state.update { it.copy(connection = s, elapsedSeconds = if (s.connectedAtMillis == null) 0 else it.elapsedSeconds) }
            }
        }
        viewModelScope.launch {
            c.diagnostics.observeLocalIpv4().collect { ip -> _state.update { it.copy(localIp = ip) } }
        }
        viewModelScope.launch {
            while (true) {
                delay(1000)
                val at = _state.value.connection.connectedAtMillis ?: continue
                _state.update { it.copy(elapsedSeconds = (System.currentTimeMillis() - at) / 1000) }
            }
        }
    }

    fun toggleConnection() {
        val s = _state.value
        when (s.connection.state) {
            ConnectionState.DISCONNECTED, ConnectionState.ERROR -> c.controller.connect(
                ConnectionConfig(s.server.code, s.server.endpoint, s.profile.id, s.profile.title)
            )
            ConnectionState.CONNECTING -> c.controller.cancel()
            ConnectionState.CONNECTED -> c.controller.disconnect()
        }
    }

    fun refreshLatencies() {
        measureJob?.cancel()
        measureJob = viewModelScope.launch {
            _state.update { it.copy(measuring = true, latencies = emptyMap()) }
            try {
                c.diagnostics.measureAll(MockData.servers.map { it.endpoint }).collect { (ep, r) ->
                    _state.update { it.copy(latencies = it.latencies + (ep to r)) }
                }
            } finally {
                _state.update { it.copy(measuring = false) }
            }
        }
    }

    fun selectServer(s: Server) = _state.update { it.copy(server = s, randomServer = false) }

    /** "Aleatório/automático": prefere o de menor latência medida; senão sorteia. */
    fun selectRandomServer() = _state.update { st ->
        val best = MockData.servers
            .mapNotNull { s -> (st.latencies[s.endpoint] as? LatencyResult.Success)?.let { s to it.ms } }
            .minByOrNull { it.second }?.first
        st.copy(server = best ?: MockData.servers.random(), randomServer = true)
    }

    fun selectProfile(p: Profile) = _state.update { it.copy(profile = p) }
    fun clearLogs() = c.logs.clear()

    companion object {
        fun factory(c: AppContainer) = viewModelFactory { initializer { AppViewModel(c) } }
    }
}
