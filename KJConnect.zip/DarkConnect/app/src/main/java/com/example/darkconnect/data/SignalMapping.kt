package com.example.darkconnect.data

import com.example.darkconnect.network.diagnostics.LatencyResult

/** Latência real -> barras de sinal. Ajuste os limiares conforme sua necessidade. */
fun LatencyResult?.toSignal(): Signal = when (this) {
    is LatencyResult.Success -> when {
        ms < 150 -> Signal.HIGH
        ms < 400 -> Signal.MEDIUM
        else -> Signal.LOW
    }
    else -> Signal.UNAVAILABLE   // não medido, timeout ou inacessível
}
