package com.example.darkconnect.network.connection

import com.example.darkconnect.network.diagnostics.LatencyResult
import com.example.darkconnect.network.diagnostics.NetworkDiagnosticsService
import com.example.darkconnect.network.log.LogRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout

/**
 * Orquestra o ciclo de conexão. Não conhece UI.
 * Os timeouts abaixo valem só para a TENTATIVA de conectar; depois de CONNECTED
 * não há timer nem expiração de sessão.
 */
class ConnectionController(
    private val diagnostics: NetworkDiagnosticsService,
    private val engine: TunnelEngine,
    private val logs: LogRepository,
    private val scope: CoroutineScope,
    private val settings: Settings = Settings(),
) {
    data class Settings(val probeTimeoutMs: Int = 4_000, val attemptTimeoutMs: Long = 20_000)

    private class ConnectFailure(message: String) : Exception(message)

    private val _status = MutableStateFlow(ConnectionStatus())
    val status: StateFlow<ConnectionStatus> = _status.asStateFlow()

    private var attemptJob: Job? = null
    private var monitorJob: Job? = null

    @Synchronized
    fun connect(config: ConnectionConfig) {
        val s = _status.value.state
        if (s == ConnectionState.CONNECTING || s == ConnectionState.CONNECTED) return
        attemptJob = scope.launch { runAttempt(config) }
    }

    /** Cancela uma tentativa em andamento. */
    @Synchronized
    fun cancel() {
        if (_status.value.state != ConnectionState.CONNECTING) return
        attemptJob?.cancel()
        logs.warn("Tentativa cancelada pelo usuário")
        scope.launch { runCatching { engine.stop() }; _status.value = ConnectionStatus() }
        _status.value = ConnectionStatus()
    }

    /** Parada limpa de uma sessão ativa (ou limpeza após erro). */
    @Synchronized
    fun disconnect() {
        attemptJob?.cancel(); monitorJob?.cancel()
        logs.info("Encerrando conexão…")
        scope.launch {
            runCatching { engine.stop() }.onFailure { logs.warn("Falha ao parar motor: ${it.message}") }
            _status.value = ConnectionStatus()
            logs.info("Desconectado")
        }
    }

    private suspend fun runAttempt(config: ConnectionConfig) {
        _status.value = ConnectionStatus(ConnectionState.CONNECTING)
        logs.info("Iniciando conexão: ${config.serverName} / ${config.profileName}")
        try {
            withTimeout(settings.attemptTimeoutMs) {
                // 1) validação
                logs.info("Validando servidor e perfil…")
                if (config.endpoint.host.isBlank() || config.endpoint.port !in 1..65535)
                    throw ConnectFailure("Servidor inválido (${config.endpoint.host}:${config.endpoint.port})")
                if (config.profileName.isBlank())
                    throw ConnectFailure("Perfil inválido")

                // 2) rede local
                logs.info("Verificando rede local…")
                val ip = diagnostics.currentLocalIpv4()
                    ?: throw ConnectFailure("Sem rede ativa (Wi-Fi ou dados móveis)")
                logs.info("Rede local ativa: $ip")

                // 3) alcance do servidor
                logs.info("Testando alcance de ${config.endpoint.host}:${config.endpoint.port}…")
                when (val r = diagnostics.measureLatency(config.endpoint, settings.probeTimeoutMs)) {
                    is LatencyResult.Success -> logs.info("Servidor respondeu em ${r.ms} ms")
                    LatencyResult.Timeout ->
                        throw ConnectFailure("Servidor não respondeu em ${settings.probeTimeoutMs} ms")
                    is LatencyResult.Unreachable ->
                        throw ConnectFailure("Servidor inacessível: ${r.reason}")
                }

                // 4) motor nativo
                logs.info("Abrindo túnel…")
                engine.start(config) { logs.info(it) }
                    .getOrElse { throw ConnectFailure(it.message ?: "Falha ao iniciar o túnel") }
            }
            currentCoroutineContext().ensureActive()
            _status.value = ConnectionStatus(ConnectionState.CONNECTED, connectedAtMillis = System.currentTimeMillis())
            logs.success("Conectado a ${config.serverName}")
            watchEngine()
        } catch (e: TimeoutCancellationException) {
            fail("Tempo esgotado na tentativa de conexão (${settings.attemptTimeoutMs / 1000}s)")
        } catch (e: CancellationException) {
            throw e // cancel()/disconnect() já ajustaram o estado
        } catch (e: ConnectFailure) {
            fail(e.message ?: "Falha na conexão")
        } catch (e: Exception) {
            fail("Erro inesperado: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun watchEngine() {
        monitorJob?.cancel()
        monitorJob = scope.launch {
            engine.disconnections.collect { reason ->
                fail("Conexão perdida: $reason")
                monitorJob?.cancel()
            }
        }
    }

    private suspend fun fail(message: String) {
        logs.error(message)
        runCatching { engine.stop() }
        _status.value = ConnectionStatus(ConnectionState.ERROR, errorMessage = message)
    }
}
