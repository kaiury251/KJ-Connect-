package com.example.darkconnect.data

import com.example.darkconnect.network.diagnostics.Endpoint

enum class Signal { UNAVAILABLE, LOW, MEDIUM, HIGH }
enum class ConnStatus { ALERT, VERIFIED }

data class Server(
    val code: String, val flag: String, val country: String,
    val host: String, val port: Int,
) {
    val endpoint get() = Endpoint(host, port)
}

data class Profile(
    val id: Int, val emoji: String, val title: String, val subtitle: String, val status: ConnStatus,
)

data class ProfileGroup(val name: String, val items: List<Profile>) {
    val count get() = items.size
}
