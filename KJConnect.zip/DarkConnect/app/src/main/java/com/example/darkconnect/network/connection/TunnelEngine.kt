package com.example.darkconnect.network.connection

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emptyFlow

/**
 * ===== PONTO DE INTEGRAÇÃO COM O MOTOR NATIVO =====
 * Implemente esta interface com o motor real (VpnService + túnel, cliente proxy, SSH...).
 *
 * Contrato:
 *  - [start] só retorna Result.success quando o túnel estiver REALMENTE estabelecido.
 *    Em qualquer falha, retorne Result.failure(Exception("motivo específico")).
 *  - [start] deve ser cancelável (suspender de forma cooperativa).
 *  - [stop] deve ser idempotente e liberar sockets/fd/serviço.
 *  - [disconnections] emite o motivo quando o túnel cai sozinho depois de conectado.
 *
 * Esboço para VpnService:
 *  1. UI/Activity: val intent = VpnService.prepare(ctx); se != null, pedir consentimento ao usuário.
 *  2. Criar `class AppVpnService : VpnService()` (declarar no Manifest com
 *     BIND_VPN_SERVICE e o intent-filter android.net.VpnService).
 *  3. No serviço: Builder().addAddress(..).addRoute(..).addDnsServer(..).establish() -> ParcelFileDescriptor.
 *  4. Encaminhar os pacotes do fd para o seu cliente proxy/SSH e proteger o socket do
 *     servidor com protect(socket) para evitar loop.
 *  5. VpnTunnelEngine.start() inicia o serviço, aguarda o estabelecimento (com cancelamento)
 *     e devolve success/failure.
 */
interface TunnelEngine {
    suspend fun start(config: ConnectionConfig, log: (String) -> Unit): Result<Unit>
    suspend fun stop()
    val disconnections: Flow<String>
}

class TunnelEngineNotIntegratedException :
    Exception("Motor de túnel não integrado (implemente TunnelEngine e troque em AppContainer).")

/** Padrão atual: falha de forma honesta em vez de fingir que conectou. */
class UnimplementedTunnelEngine : TunnelEngine {
    override suspend fun start(config: ConnectionConfig, log: (String) -> Unit) =
        Result.failure<Unit>(TunnelEngineNotIntegratedException())
    override suspend fun stop() = Unit
    override val disconnections: Flow<String> = emptyFlow()
}
