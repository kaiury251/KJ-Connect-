package com.example.darkconnect.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AllInclusive
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.darkconnect.AppState
import com.example.darkconnect.data.MockData
import com.example.darkconnect.data.toSignal
import com.example.darkconnect.network.connection.ConnectionState
import com.example.darkconnect.ui.components.*
import com.example.darkconnect.ui.theme.AppColors

@Composable
fun HomeScreen(
    state: AppState,
    onToggle: () -> Unit,
    onOpenServers: () -> Unit,
    onOpenConnections: () -> Unit,
    onOpenLogs: () -> Unit,
    onAdd: () -> Unit,
) {
    val ctx = LocalContext.current
    val version = remember {
        runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "—"
    }
    Column(Modifier.fillMaxSize().background(AppColors.Black)) {
        TopStatusBar(state, onAdd)

        Column(
            Modifier.weight(1f).padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceEvenly
        ) {
            PowerButton(state.connection.state, onToggle)
            InfoBlock(version, state.localIp ?: "SEM REDE")
            GradientPill(MockData.APP_NAME)

            AppCard(onClick = onOpenServers) {
                EmojiBadge(state.server.flag)
                TitleSubtitle(
                    if (state.randomServer) "ALEATÓRIO • ${state.server.code}" else state.server.code,
                    state.server.country, Modifier.weight(1f).padding(start = 12.dp)
                )
                SignalBars(state.latencies[state.server.endpoint].toSignal())
            }
            AppCard(onClick = onOpenConnections) {
                EmojiBadge(state.profile.emoji)
                TitleSubtitle(state.profile.title, state.profile.subtitle, Modifier.weight(1f).padding(start = 12.dp))
                StatusIcon(state.profile.status)
            }
        }

        Spacer(Modifier.height(28.dp))
        AppBottomBar({}, onOpenLogs, onToggle, {}, {})
    }
}

@Composable
private fun TopStatusBar(state: AppState, onAdd: () -> Unit) {
    val s = state.connection.state
    val (label, color) = when (s) {
        ConnectionState.CONNECTED -> "CONECTADO" to AppColors.Green
        ConnectionState.CONNECTING -> "CONECTANDO…" to AppColors.Yellow
        ConnectionState.ERROR -> "ERRO" to AppColors.Red
        ConnectionState.DISCONNECTED -> "DESCONECTADO" to AppColors.TextSecondary
    }
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(10.dp).clip(CircleShape).background(color))
        Column(Modifier.weight(1f).padding(start = 10.dp)) {
            Text(label, style = MaterialTheme.typography.titleMedium, color = AppColors.TextPrimary)
            if (s == ConnectionState.ERROR && state.connection.errorMessage != null) {
                Text(state.connection.errorMessage, style = MaterialTheme.typography.labelSmall, color = AppColors.Red)
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.AllInclusive, null, Modifier.size(14.dp), tint = AppColors.Cyan)
                    val elapsed = if (s == ConnectionState.CONNECTED) " • ${formatElapsed(state.elapsedSeconds)}" else ""
                    Text(" SESSÃO ILIMITADA$elapsed", style = MaterialTheme.typography.labelSmall, color = AppColors.Cyan)
                }
            }
        }
        Text(
            "+ADD",
            Modifier.clip(RoundedCornerShape(10.dp)).border(1.dp, AppColors.Cyan, RoundedCornerShape(10.dp))
                .clickable(onClick = onAdd).padding(horizontal = 12.dp, vertical = 6.dp),
            style = MaterialTheme.typography.labelSmall, color = AppColors.Cyan
        )
    }
}

@Composable
private fun InfoBlock(version: String, ip: String) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(AppColors.Card)
            .border(1.dp, AppColors.Border, RoundedCornerShape(12.dp)).padding(12.dp),
        horizontalArrangement = Arrangement.SpaceAround
    ) {
        InfoItem("VERSION", version)
        InfoItem("IP LOCAL", ip)
    }
}

@Composable
private fun InfoItem(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = AppColors.TextSecondary)
        Text(value, style = MaterialTheme.typography.titleMedium, color = AppColors.TextPrimary)
    }
}

private fun formatElapsed(s: Long) = "%02d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
