# DarkConnect — UI (Kotlin + Jetpack Compose)

Somente interface, com dados mockados. Nenhuma lógica de rede/túnel está incluída.

## Arquitetura
app/src/main/java/com/example/darkconnect
- MainActivity.kt          -> host + navegação simples por estado (Route)
- AppViewModel.kt          -> estado único (AppState); tempo decorrido (count-up), sem expiração
- data/Models.kt, MockData.kt -> modelos e dados mockados (BR 01..51, USA 11..20, perfis, grupos)
- ui/theme/Theme.kt        -> cores (#000/#0A0B0E, cards #1E2026/#2A2D36), tipografia
- ui/components/Components.kt -> PowerButton, AppCard, SignalBars, BottomBar, headers
- ui/home | connections | servers -> telas

Padrão: UDF (estado desce, eventos sobem). Produção: trocar MockData por Repository + Navigation Compose.

## Camada de rede (v2)
network/diagnostics -> IP local real + latência TCP (NetworkDiagnosticsService)
network/connection  -> ConnectionController + TunnelEngine (ponto de integração do motor)
network/log         -> LogRepository (tela REGISTRO)
AppContainer.kt     -> DI manual; troque `engine` pelo motor real.
